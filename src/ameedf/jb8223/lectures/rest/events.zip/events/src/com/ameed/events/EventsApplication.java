package com.ameed.events;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/rest/api")
public class EventsApplication extends Application {

}
